# Pajak Air — Build APK langsung dari HP

Project ini disiapkan agar APK dapat dibuat menggunakan **GitHub Actions**, tanpa PC dan tanpa Android Studio.

## Langkah dari HP
1. Buat akun/login GitHub.
2. Buat repository baru, misalnya `PajakAir`.
3. Upload **seluruh isi project** ini ke repository. Folder `.github/workflows/` harus ikut.
4. Buka tab **Actions**.
5. Pilih **Build APK Pajak Air**.
6. Tekan **Run workflow**.
7. Tunggu sampai job selesai dengan tanda centang hijau.
8. Buka hasil workflow tersebut.
9. Di bagian **Artifacts**, download `PajakAir-debug-apk`.
10. Extract ZIP artifact dan install `app-debug.apk`.

## Tidak perlu Gradle Wrapper
Workflow memakai `gradle/actions/setup-gradle` untuk menyiapkan Gradle 8.10.2 di server GitHub. Jadi project ini **tidak membutuhkan file gradlew/gradle-wrapper.jar** untuk build lewat GitHub Actions.

## Setelah terpasang
Aplikasi bekerja offline. Data pelanggan disimpan di penyimpanan lokal WebView HP.

## Rumus
`(Meter akhir - Meter awal) × Rp4.000`
