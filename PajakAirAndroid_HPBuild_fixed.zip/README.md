# Pajak Air - Android Offline

Project Android Studio lengkap untuk aplikasi penagihan Pajak Air.

## Fitur
- Berjalan offline
- Data tersimpan di localStorage/WebView HP
- Input nama, ID, alamat, meter awal, meter akhir
- Rumus: (meter akhir - meter awal) x Rp4.000
- Status Lunas / Belum Bayar
- Pencarian
- Rekap total tagihan dan tunggakan

## Build APK
1. Buka folder `PajakAirAndroid` di Android Studio.
2. Tunggu Gradle selesai melakukan sync (internet mungkin diperlukan saat pertama kali mengunduh dependency).
3. Pilih `Build > Build App Bundle(s) / APK(s) > Build APK(s)`.
4. APK debug biasanya berada di:
   `app/build/outputs/apk/debug/app-debug.apk`

## Catatan
Setelah APK terpasang, penggunaan aplikasi dan data penagihan tidak memerlukan internet.
