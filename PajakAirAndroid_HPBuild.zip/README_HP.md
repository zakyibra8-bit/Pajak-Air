# Pajak Air — Build APK dari HP

Project ini bisa dipakai untuk menghasilkan APK lewat GitHub Actions tanpa PC.

## Yang dibutuhkan
- HP Android
- Akun GitHub
- Browser (Chrome, misalnya)
- Internet hanya untuk proses build/download. APK hasilnya dapat dipakai offline.

## Cara paling mudah
1. Buat repository baru di GitHub, misalnya `PajakAir`.
2. Upload seluruh isi folder project ini ke repository.
3. Pastikan file `.github/workflows/build-apk.yml` ikut ter-upload.
4. Buka tab **Actions** pada repository.
5. Pilih workflow **Build APK Pajak Air**.
6. Tekan **Run workflow** jika workflow manual tersedia.
7. Tunggu sampai proses selesai.
8. Buka hasil workflow tersebut dan cari bagian **Artifacts**.
9. Download `PajakAir-debug-apk`.
10. Extract ZIP artifact lalu install `app-debug.apk` di HP.

## Catatan penting
Project ini memerlukan Gradle Wrapper (`gradlew`, `gradlew.bat`, dan folder `gradle/wrapper`) untuk build langsung di GitHub Actions. Jika repository tidak memiliki wrapper, Android Studio/Gradle lokal biasanya dipakai untuk membuatnya.

Alternatif: gunakan template Android project yang sudah memiliki Gradle Wrapper lalu salin source `app/` dan workflow ini ke dalamnya.

## Fitur aplikasi
- Offline setelah APK terpasang
- Tarif Rp4.000/m³
- Meter awal dan meter akhir
- Perhitungan pemakaian otomatis
- Status Lunas/Belum Bayar
- Pencarian pelanggan
- Rekap tagihan dan tunggakan
